function [im1]=show(im1)
hold off;
imagesc(im1);
colormap(gray);
axis image;